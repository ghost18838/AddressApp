package sample.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;

import java.time.LocalDate;

public class Address {
    public static final String TABLE_NAME = "addres";
    public static final String ID_COLUMN = "id";
    public static final String FIRST_NAME_COLUMN = "firstName";
    public static final String LAST_NAME_COLUMN = "lastName";
    public static final String STREET_COLUMN = "street";
    public static final String CITY_COLUMN = "city";
    public static final String POSTAL_CODE_COLUMN = "postalCode";
    public static final String BIRTHDAY_COLUMN = "birthday";
    public static final String FOTO_COLUMN = "foto";

    private int id;
    private String firstName;
    private String lastName;
    private String street;
    private String city;
    private String postalCode;
    private LocalDate birthday;
    private String imgP;

    public Address(){
    }
    public Address(String firstName,String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
    }  public Address(String firstName, String lastName, String street, String city, String postalCode, LocalDate birthday , String imgP) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
        this.birthday = birthday;
        this.imgP = imgP;
    }
    public Address(int id,String firstName, String lastName, String street, String city, String postalCode, LocalDate birthday , String imgP) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
        this.birthday = birthday;
        this.imgP = imgP;
    }

    public String getImgP() {
        return imgP;
    }
    public void setImgP(String imgP) {
        this.imgP = imgP;
    }
    public int getId(){
        return id;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getStreet() {
        return street;
    }
    public void setStreet(String street) {
        this.street = street;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getPostalCode() {
        return postalCode;
    }
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    public LocalDate getBirthday() {
        return birthday;
    }
    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s,%s,%s,%tF,%s",getId(),getFirstName(),getLastName(),getStreet(),getCity(),getPostalCode(),getBirthday(),getImgP());
    }
}
