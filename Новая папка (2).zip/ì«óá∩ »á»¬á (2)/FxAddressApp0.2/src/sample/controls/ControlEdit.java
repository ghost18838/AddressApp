package sample.controls;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import sample.DAO.impl.PersonImpl;
import sample.DBConnect;
import sample.model.Address;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ControlEdit {
    @FXML
    public Button botOk;@FXML
    public Button botCancl;
    public Button botReturn;
    public TextField filePath;
    public Button fileCooser;
    private Connection con;
    @FXML
    private TextField firstNameText;@FXML
    private TextField lastNameText;@FXML
    private TextField streetText;@FXML
    private TextField cityText;@FXML
    private TextField postalCodeText;@FXML
    private TextField birthdayText;

    private static String firsNStr ;
    private static String lastNStr ;
    private static String streetStr ;
    private static String cityStr ;
    private static String postalStr ;
    private static String birthdayStr ;
    private static int idToUp;
    private static String choosenFile;


    @FXML
    public void initialize(){
        botReturn.setOnAction(ActionEvent ->{
            firstNameText.setText(firsNStr);
            lastNameText.setText(lastNStr);
            streetText.setText(streetStr);
            postalCodeText.setText(postalStr);
            cityText.setText(cityStr);
            birthdayText.setText(birthdayStr);
            filePath.setText(choosenFile);
        });
        {//filds init
            firstNameText.setText(firsNStr);
            lastNameText.setText(lastNStr);
            streetText.setText(streetStr);
            postalCodeText.setText(postalStr);
            cityText.setText(cityStr);
            birthdayText.setText(birthdayStr);
            filePath.setText(choosenFile);
        }
        fileCooser.setOnAction(ActionEvent ->{
            FileChooser fCH = new FileChooser();
            Stage stage = new Stage();
            Parent root = null;
            File file = fCH.showOpenDialog(stage);
            if (file != null){
                filePath.setText(file.getAbsolutePath());
            }
        });
        botCancl.setOnAction(ActionEvent -> {
            botCancl.getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/sample/view/MainView.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.setTitle("Hello World");
            stage.setScene(new Scene(root));
            stage.show();
        });
        botOk.setOnAction(ActionEvent->{
            PersonImpl imp = new PersonImpl();
                String firstNameToUP = firstNameText.getText();
                String lastNameToUP = lastNameText.getText();
                String streetToUP = streetText.getText();
                String cityToUP = cityText.getText();
                String postalToUP = postalCodeText.getText();
                String birthdayToUP = birthdayText.getText();
                int idToUP = idToUp;
                String fipePToUP = filePath.getText();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate ldBirthday = LocalDate.parse(birthdayToUP,dtf);
            imp.update(new Address(idToUP,firstNameToUP,lastNameToUP,streetToUP,cityToUP,postalToUP,ldBirthday,fipePToUP));
            //closeBox
            botOk.getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/sample/view/MainView.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.setTitle("Hello World");
            stage.setScene(new Scene(root));
            stage.show();
        });
    }
    public static void setPerson(Address person) {
        firsNStr = person.getFirstName();
        lastNStr = person.getLastName();
        streetStr = person.getStreet();
        cityStr = person.getCity();
        postalStr = person.getPostalCode();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        birthdayStr = dtf.format(person.getBirthday());
        choosenFile = person.getImgP();
        idToUp = person.getId();
    }
}
