package sample.controls;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import sample.DAO.impl.PersonImpl;
import sample.DBConnect;
import sample.model.Address;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ControlAdd {
    public Button fotoChuuser;
    public TextField filePath;
    ControlAddres idShka;
    @FXML
    private Button botOk;@FXML
    private Button botCancl;
    private Connection con;
    @FXML
    private TextField firstNameText;@FXML
    private TextField lastNameText;@FXML
    private TextField streetText;@FXML
    private TextField cityText;@FXML
    private TextField postalCodeText;@FXML
    private TextField birthdayText;
    @FXML
    public void initialize(){
        fotoChuuser.setOnAction(ActionEvent->{
            FileChooser fCH = new FileChooser();
            Stage stage = new Stage();
            Parent root = null;
            File file = fCH.showOpenDialog(stage);
            if (file != null){
                filePath.setText(file.getAbsolutePath());
            }
        });
        botCancl.setOnAction(ActionEvent->{
            botCancl.getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/sample/view/MainView.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.setTitle("Hello World");
            stage.setScene(new Scene(root));
            stage.show();
        });
        botOk.setOnAction(ActionEvent->{
            PersonImpl impl = new PersonImpl();
               String firstToInsert = firstNameText.getText();
               String lastToInsert = lastNameText.getText();
               String streetToInsert = streetText.getText();
               String cityToInsert = cityText.getText();
               String postaToInsert = postalCodeText.getText();
               String birthdayToInsert = birthdayText.getText();
               String filePToInsert = filePath.getText();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate ldBirthday = LocalDate.parse(birthdayToInsert,dtf);
                impl.insert(new Address(firstToInsert,lastToInsert,streetToInsert,cityToInsert,postaToInsert,ldBirthday,filePToInsert));
            //closeBloke
            {
            botOk.getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/sample/view/MainView.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.setTitle("Hello World");
            stage.setScene(new Scene(root));
            stage.show();}
        });
    }
}
