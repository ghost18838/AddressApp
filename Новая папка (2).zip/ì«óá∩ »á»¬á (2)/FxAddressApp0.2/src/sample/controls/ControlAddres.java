package sample.controls;

import javafx.beans.property.IntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import sample.DAO.PersomDao;
import sample.DAO.impl.PersonImpl;
import sample.DBConnect;
import sample.Main;
import sample.model.Address;

import java.awt.event.ActionEvent;
import java.io.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class ControlAddres{
    PersonImpl impl;
    public ImageView fotoIMG;
    private int delID;
    public Button botDell;
    public Button botEdit;
    public Button boNew;
    private Connection con;
    private ObservableList<Address> listUsers = FXCollections.observableArrayList();
    @FXML
    private TableView<Address> addressTable;
    @FXML
    private TableColumn<Address,String> firstNameColumn;
    @FXML
    private TableColumn<Address,String> lastNameColumn;

    @FXML
    private Label firsNaemLable;
    @FXML
    private Label lastNameLabel;
    @FXML
    private Label streetLabel;
    @FXML
    private Label cityLabel;
    @FXML
   private Label postalCodeLabel;
    @FXML
    private Label birthdayLabel;
    @FXML
    public void initialize() throws ClassNotFoundException {
        boNew.setOnAction(ActionEvent -> {
            boNew.getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/sample/view/AddView.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.setTitle("Hello World");
            stage.setScene(new Scene(root));
            stage.show();
        });
        botEdit.setOnAction(ActionEvent ->{
            botEdit.getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/sample/view/editView.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.setTitle("Hello World");
            stage.setScene(new Scene(root));
            stage.show();
        });
        botDell.setOnAction(ActionEvent->{
            PersonImpl impl = new PersonImpl();
            impl.delete();
            botEdit.getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/sample/view/MainView.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.setTitle("Hello World");
            stage.setScene(new Scene(root));
            stage.show();
        });
        initData();
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<Address,String>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<Address,String>("lastName"));
        addressTable.setItems(listUsers);
        writeToCSV();
    }

    public void initData(){
        impl = new PersonImpl();
        for (Address address:impl.findAll()){
            listUsers.add(address);
        }
        showPersonDetails(null);
        addressTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showPersonDetails(newValue));
    }
    private void showPersonDetails(Address person) {
        if (person != null) {
            // Заполняем метки информацией из объекта person.
            firsNaemLable.setText(person.getFirstName());
            lastNameLabel.setText(person.getLastName());
            streetLabel.setText(person.getStreet());
            postalCodeLabel.setText(person.getPostalCode());
            cityLabel.setText(person.getCity());
            birthdayLabel.setText(person.getBirthday().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            try {fotoIMG.setImage(new Image(new FileInputStream(person.getImgP())));}
            catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            ControlEdit.setPerson(person);
            PersonImpl.setPerson(person);
         delID = person.getId();
        } else {
            firsNaemLable.setText("");
            lastNameLabel.setText("");
            streetLabel.setText("");
            postalCodeLabel.setText("");
            cityLabel.setText("");
            birthdayLabel.setText("");
        }
    }
    private void writeToCSV() {
        Calendar cal = new GregorianCalendar();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm");
        String formattedTime = sdf.format(cal.getTime());
        System.out.println(formattedTime);
        File dr = new File("resurses/"+formattedTime);
        dr.mkdir();
        File file = new File("resurses/"+formattedTime+"/Damp.csv");
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try(FileWriter fw = new FileWriter(file)) {
            String tablesToCSV = "id,firstName,lastName,street,city,postalCode,birthday,foto";

            fw.write(tablesToCSV);
            fw.write("\n");
            for (Address address : listUsers) {
                fw.write(address.toString());
                fw.write("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
