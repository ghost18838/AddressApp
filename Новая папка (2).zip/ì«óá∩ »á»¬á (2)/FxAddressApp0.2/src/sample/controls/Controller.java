package sample.controls;

public class Controller {
}
