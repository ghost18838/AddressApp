package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
    public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    public static final String URL ="jdbc:mysql://localhost:3306/address?serverTimezone=UTC";
    public static final String USER = "user";
    public static final String PASSWORD = "1234";

    public static Connection getConnection(){
        Connection connection = null;
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            connection = DriverManager.getConnection(URL,USER,PASSWORD);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return connection;
    }
    public void closeConnection(Connection connection){
        if (connection == null)return;
        try {
            connection.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
