package sample.DAO;

import sample.model.Address;

import java.util.List;

public interface PersomDao {
    String SQL_FIND = String.format("SELECT * FROM %s",Address.TABLE_NAME);
    String SQL_DELETE= String.format("DELETE FROM %s WHERE (%s = ?);", Address.TABLE_NAME,Address.ID_COLUMN);
    String SQL_INSERT = String.format("INSERT INTO %s (%s,%s,%s,%s,%s,%s,%s) VALUES (?,?,?,?,?,?,?);", Address.TABLE_NAME,
            Address.FIRST_NAME_COLUMN,Address.LAST_NAME_COLUMN,Address.STREET_COLUMN,Address.CITY_COLUMN,
            Address.POSTAL_CODE_COLUMN,Address.BIRTHDAY_COLUMN,Address.FOTO_COLUMN);
    String SQL_UPDATE = String.format("UPDATE %s SET %s=?,%s=?,%s=?,%s=?,%s=?,%s=?,%s=? WHERE (%s=?);", Address.TABLE_NAME,
            Address.FIRST_NAME_COLUMN,Address.LAST_NAME_COLUMN,Address.STREET_COLUMN,Address.CITY_COLUMN,
            Address.POSTAL_CODE_COLUMN,Address.BIRTHDAY_COLUMN,Address.FOTO_COLUMN,Address.ID_COLUMN);

    List<Address> findAll();
    void delete();
    void insert(Address address);
    void update(Address address);
}
