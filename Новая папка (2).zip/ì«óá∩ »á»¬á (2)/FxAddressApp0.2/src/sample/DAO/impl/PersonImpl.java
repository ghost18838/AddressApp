package sample.DAO.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import sample.DAO.PersomDao;
import sample.DBConnect;
import sample.model.Address;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PersonImpl implements PersomDao {
    private Connection con;
    private static int idToUp;

    @Override
    public List<Address> findAll( ) {
        List<Address> userList = FXCollections.observableArrayList();
        Address address = null;
        con = DBConnect.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement(PersomDao.SQL_FIND);
                ResultSet result = statement.executeQuery();
                while (result.next()){

                  int  DBId = result.getInt(Address.ID_COLUMN);
                  String  DBFirstName = result.getString(Address.FIRST_NAME_COLUMN);
                  String  DBLastName = result.getString(Address.LAST_NAME_COLUMN);
                  String  DBStreet = result.getString(Address.STREET_COLUMN);
                  String  DBCity = result.getString(Address.CITY_COLUMN);
                  String  DBPostalCode = result.getString(Address.POSTAL_CODE_COLUMN);
                  String  DBBirthday = result.getString(Address.BIRTHDAY_COLUMN);
                  String  DBFoto = result.getNString(Address.FOTO_COLUMN);
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate ld = LocalDate.parse(DBBirthday,dtf);
                    address = new Address(DBId,DBFirstName,DBLastName,DBStreet,DBCity,DBPostalCode,ld,DBFoto);
                    userList.add(address);
                }
                con.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return userList;
    }

    @Override
    public void delete() {
        con = DBConnect.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement(PersomDao.SQL_DELETE);
            statement.setInt(1,idToUp);
            statement.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void insert(Address address) {
        con = DBConnect.getConnection();
        PreparedStatement statement = null;
        try {
            statement = con.prepareStatement(PersomDao.SQL_INSERT);
            statement.setString(1,address.getFirstName());
            statement.setString(2,address.getLastName());
            statement.setString(3,address.getStreet());
            statement.setString(4,address.getCity());
            statement.setString(5,address.getPostalCode());
            statement.setString(6,String.format("%tF",address.getBirthday()));
            statement.setString(7,address.getImgP());
            statement.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    @Override
    public void update(Address address) {
        con = DBConnect.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement(PersomDao.SQL_UPDATE);
            statement.setString(1,address.getFirstName());
            statement.setString(2,address.getLastName());
            statement.setString(3,address.getStreet());
            statement.setString(4,address.getCity());
            statement.setString(5,address.getCity());
            statement.setString(6,address.getPostalCode());
            statement.setString(7,address.getImgP());
            statement.setInt(8,idToUp);

            statement.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }
    public static void setPerson(Address person) {
        idToUp = person.getId();
    }
}
