package com.company;


import Model.User;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Program {
    public static void main(String[] args) throws IOException, SQLException {
     DataBase dataBase = new DataBase();
     Connection connection = dataBase.getConnect();
     List<User> users = new ArrayList<>();

     try {
         String sqlSelect = "SELECT * FROM" + User.TABLE_NAME;
         PreparedStatement statement = connection.prepareStatement(sqlSelect);
         ResultSet resultSet = statement.executeQuery();
         User user = null;
         while (resultSet.next()) {
             int id = resultSet.getInt(User.ID_COLUMN);
             String firstName = resultSet.getString(User.FIRST_NAME_COLUMN);
             String login = resultSet.getString(User.LOGIN_COLUMN);
             String password = resultSet.getString(User.PASSWORD_COLUMN);
             user = new User(id, firstName, login, password);
             users.add(user);
         }
     }catch (SQLException throwables) {
         throwables.printStackTrace();
     }

     for (User user : users){
         System.out.println(user);
     }

     try(BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))){
         System.out.println("Input -c or -u or -d");
         String crud = reader.readLine();
         if (crud.equals("-c")) {
             System.out.println("Input firstName:");
             String firstName = reader.readLine();
             System.out.println("Input login:");
             String login = reader.readLine();
             System.out.println("Input password:");
             String password = reader.readLine();

             User user = new User(users.size() +1, firstName, login,password);

             try {
                 String sqlInsert = String.format("INSERT INTO %s(%s, %s, %s)VALUES(?,?,?)",
                 User.TABLE_NAME, User.FIRST_NAME_COLUMN, User.LOGIN_COLUMN, User.PASSWORD_COLUMN, User.ID_COLUMN);
                 PreparedStatement statement = connection.prepareStatement(sqlInsert);
                 statement.setString(1, user.getFirstName());
                 statement.setString(2, user.getLogin());
                 statement.setString(3,user.getPassword());
                 int i= statement.executeUpdate();
                 if (i == 1){
                     System.out.println("Данные добавлены");
                 }
             }



         }
     }

    }

}
